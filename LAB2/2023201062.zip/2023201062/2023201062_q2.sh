#!/bin/bash

cd $1

ls -l | grep -e ".rwx-w-..x"