## 2023201062_q1.sh
    PATTERN 1 is followed.
    input: read is used to give input.
    command: ./2023201062_q1.sh
    then enter total no. of pyramids.
    after that give number of rows for each pyramid.

## 2023201062_q2.sh
    input: pass directory name as input to search for files with required premissions.
    command: ./2023201062_q2.sh ./directory_name