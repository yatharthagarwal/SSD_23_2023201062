#!/bin/bash

read pyramids

for (( i=1; i<=$pyramids; i++ )) do
    read rows
    if [[ $rows%2 -ne 0 ]]; then
        star=1
        spac=$(expr $rows / 2)
        spa=$(expr $spac + 1)
        inc=1
        for (( row=0; row<$rows; row++ )) do
            if [[ $inc -eq 1 ]]; then
                for (( sp=0; sp<$spa; sp++ )) do
                    echo -n " "
                done
                for (( st=0; st<$star; st++ )) do
                    if [[ st -eq $(expr $star - 1) ]]; then
                        echo -e "*\n"
                    else
                        echo -n "*"
                    fi
                done
                if [[ $star -ne $rows ]]; then
                    star=$(expr $star + 2)
                    spa=$(expr $spa - 1)
                else
                    inc=0
                fi
            else
                star=$(expr $star - 2)
                spa=$(expr $spa + 1)
                for (( sp=0; sp<$spa; sp++ )) do
                    echo -n " "
                done
                for (( st=0; st<$star; st++ )) do
                    if [[ st -eq $(expr $star - 1) ]]; then
                        echo -e "*\n"
                    else
                        echo -n "*"
                    fi
                done
            fi
        done
    fi
done