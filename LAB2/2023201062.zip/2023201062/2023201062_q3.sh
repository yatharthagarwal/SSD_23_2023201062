#!/bin/bash

cd $1
echo $(pwd)
for file in $(grep ".cpp$" ./); do
    cat file | grep "^#include"
    # while cat $file | read -r line; do
    #     grep -r "^#include" $line | echo $line
    # done
done 