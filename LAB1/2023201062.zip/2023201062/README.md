#2023201062_q1.sh

a.) execute the command using 2023201062_q1.sh ./input.txt
b.)Assumptions: for even number of lines, greatest integer function of the total_lines/2 is taken into account, and for odd number of lines, greatest integer function of the total_lines/2 +1 is taken into account.

#2023201062_q2.sh

a.) execute the command using 2023201062_q2.sh ./directory
b.) get all files, folder in current directory only.

