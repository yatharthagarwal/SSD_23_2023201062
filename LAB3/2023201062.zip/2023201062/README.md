# Directions to run queries.

1. For each of the parts of first and second questions select a single query and then run if it contains multiple queries.

Note: For some questions NULL values are not mentioned to be filtered so they are kept as part of results.

# 2023201062_q2_B.sql
In this part, some books are not present in "books" table but there reference is present in "issues_users" table. For such cases, the genre name "NULL" with that many useres under it are present.
